USE bike_factory;

-- 1) Display the names of all assembly employees that live in city that start with 'A'
SELECT 
    first_name, last_name, city
FROM
    personal,
    department,
    address
WHERE
    personal.department_id = department.department_id
        AND department.department_name = 'Assembly'
        AND personal.address_id = address.address_id
        AND address.city LIKE 'A%';

-- 2) Display the number of employees in each department from the highest to lowest
SELECT 
    department_name, COUNT(*) AS number_of_employees
FROM
    personal,
    department
WHERE
    personal.department_id = department.department_id
GROUP BY department.department_name
ORDER BY number_of_employees DESC;

-- 3) Display the customer who bought the most parts
SELECT 
    customer_fname,
    customer_lname,
    COUNT(customer_orders.customer_id) AS number_of_orders
FROM
    customer,
    customer_orders
WHERE
    customer.customer_id = customer_orders.customer_id
GROUP BY customer_orders.customer_id
ORDER BY number_of_orders DESC
LIMIT 1;

-- 4) Display the city of the customer who bought the most expensive part
SELECT 
    city, MAX(bike_parts.price) AS part_price
FROM
    customer,
    address,
    customer_orders,
    bike_parts
WHERE
    customer.address_id = address.address_id
        AND customer.customer_id = customer_orders.customer_id
GROUP BY customer_orders.customer_id
ORDER BY part_price DESC
LIMIT 1;

-- 5) Displays the out-of-stock bike_parts and company details from which you can order (not include full bike set)
SELECT DISTINCT
    bike_parts.part_name,
    bike_parts.company_name,
    bike_parts.part_type,
    supplier.phone_number
FROM
    bike_parts,
    supplier
WHERE
    bike_parts.amount = 0
        AND NOT bike_parts.part_type = 'full bike set'
        AND bike_parts.company_name = supplier.supplier_name;

-- 6) Display all the orders from suppliers in 2020 
SELECT DISTINCT
    bike_parts.part_name,
    bike_parts.company_name,
    bike_parts.part_type,
    supply_orders.date_of_supply
FROM
    bike_parts,
    supply_orders,
    supplier
WHERE
    bike_parts.part_id = supply_orders.part_id
        AND supply_orders.date_of_supply >= '2020-01-01'
        AND supply_orders.date_of_supply <= '2020-12-31'
ORDER BY supply_orders.date_of_supply;

-- 7) select - shows the 5 items with full price that have least amount of inventory DESIGNED FOR CEO USER
SELECT 
    CONCAT(part_name, '|', part_type, '|') AS 'full name',
    price,
    amount
FROM
    bike_parts
ORDER BY amount
LIMIT 5;

-- 8) select - shows contact info from supplier orders from year 2020 and onwards  (limited to the current database); DESIGNED FOR CEO USER
-- The magic number "1241354" indicate the end of the table, can use any big number
SELECT DISTINCT
    CONCAT(supplier_name,
            '|',
            phone_number,
            '|',
            email) AS 'Supplier contact info with ',
    date_of_supply
FROM
    supplier,
    supply_orders,
    address
WHERE
    supply_orders.supplier_id = supplier.supplier_id
ORDER BY date_of_supply
LIMIT 5 , 1241354;

-- 9) Top 3 Most Popular Items that being orderd from customers
SELECT 
    CONCAT(bike_parts.part_name,
            '|',
            bike_parts.company_name) AS 'Most Popular Items',
    price
FROM
    customer_orders
        JOIN
    bike_parts ON bike_parts.part_id = customer_orders.part_id
ORDER BY customer_orders.part_id , bike_parts.price
LIMIT 3;

-- 10)gives the list of all workers in the department of assembly men (full name + date of birth + email)// DESIGNED FOR ASSEMBLY WORKER
-- department_id = 3 -> assembly department, can be seen in the department table.
SELECT DISTINCT
    CONCAT(personal.first_name,
            ' ',
            personal.last_name) AS 'full name',
    (personal.date_of_birth) AS 'Birthday',
    (personal.email) AS 'Way To Contact'
FROM
    department
        JOIN
    personal ON department.department_id = personal.department_id
WHERE
    personal.department_id = 3
ORDER BY personal.date_of_birth;

-- 11)gives the list of all bike parts without the price sorted by amount // need checking DESIGNED FOR ASEMBLY WORKER
SELECT 
    CONCAT(part_type, ' - ', part_name) AS 'Name',
    part_id AS 'ID',
    amount AS 'In Stock'
FROM
    bike_parts
ORDER BY amount;
    
-- 12) ceo check how much spaces is taken in his storage in the factory  // DESIGNED FOR CEO 
SELECT 
    CONCAT(personal.first_name,
            ' ',
            personal.last_name) AS CEO,
    SUM(bike_parts.amount) AS 'overall inventory'
FROM
    personal,
    bike_parts;