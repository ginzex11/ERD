USE bike_factory;

ALTER TABLE address
MODIFY COLUMN address_id INT NOT NULL AUTO_INCREMENT,
ADD CONSTRAINT pk_address_id PRIMARY KEY (address_id);

ALTER TABLE department
MODIFY COLUMN department_id INT NOT NULL AUTO_INCREMENT,
ADD CONSTRAINT pk_department_id PRIMARY KEY (department_id);

ALTER TABLE personal
MODIFY COLUMN personal_id INT NOT NULL AUTO_INCREMENT,
ADD CONSTRAINT pk_personal_id PRIMARY KEY (personal_id),
ADD CONSTRAINT fk_personal_personal_type FOREIGN KEY (department_id) REFERENCES department(department_id),
ADD CONSTRAINT fk_personal_address_id FOREIGN KEY (address_id) REFERENCES address(address_id);

ALTER TABLE bike_parts
MODIFY COLUMN part_id INT NOT NULL AUTO_INCREMENT,
ADD CONSTRAINT pk_part_id PRIMARY KEY (part_id);

ALTER TABLE supplier
MODIFY COLUMN supplier_id INT NOT NULL AUTO_INCREMENT,
ADD CONSTRAINT pk_supplier_id PRIMARY KEY (supplier_id),
ADD CONSTRAINT fk_supplier_address_id FOREIGN KEY (address_id) REFERENCES address(address_id);

ALTER TABLE customer
MODIFY COLUMN customer_id INT NOT NULL AUTO_INCREMENT,
ADD CONSTRAINT pk_customer_id PRIMARY KEY (customer_id),
ADD CONSTRAINT fk_customer_address_id FOREIGN KEY (address_id) REFERENCES address(address_id);

ALTER TABLE supply_orders
MODIFY COLUMN order_number INT NOT NULL AUTO_INCREMENT,
ADD CONSTRAINT pk_supply_order_number PRIMARY KEY (order_number),
ADD CONSTRAINT fk_supplier_id FOREIGN KEY (supplier_id) REFERENCES supplier(supplier_id),
ADD CONSTRAINT fk_supply_part_id FOREIGN KEY (part_id) REFERENCES bike_parts(part_id);

ALTER TABLE customer_orders
MODIFY COLUMN order_number INT NOT NULL AUTO_INCREMENT,
ADD CONSTRAINT pk_customer_order_number PRIMARY KEY (order_number),
ADD CONSTRAINT fk_customer_id FOREIGN KEY (customer_id) REFERENCES customer(customer_id),
ADD CONSTRAINT fk_customer_part_id FOREIGN KEY (part_id) REFERENCES bike_parts(part_id);