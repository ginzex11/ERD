USE bike_factory;

-- For supplier
-- Insert new tyres part from supplier id 1
INSERT INTO bike_parts (part_name, company_name, part_type, price, amount) VALUES 
('Unknown tyres', (SELECT supplier_name FROM supplier WHERE supplier_id = 1), 'tyres', 100, 0);

-- Update the bike parts that out-of-stock to be 300
UPDATE bike_parts
SET amount = 300
WHERE part_id IN (SELECT 
            bike_parts.part_id
        WHERE
			bike_parts.amount = 0);
      
-- update all full bike sets that cost 19999 to be 14599  
UPDATE bike_parts 
SET 
    price = 14599
WHERE
    part_type = 'full bike set'
        AND price = 19999;
            
-- For customer
-- add new address for new customer
INSERT INTO address (city, street_name, street_number) VALUES
("Driggs", "Arbor Court", 4079);

-- add new customer
INSERT INTO customer (address_id, customer_fname, customer_lname, customer_type, phone_number, email) VALUES
(46, "James", "Jacobs", "Shop", 053337343, "wbeopwcmp243@gmail.com");

-- add new order for customer id = 16
INSERT INTO customer_orders (customer_id, part_id, date_of_supply) VALUES
(16, 14, '2021-02-25');

-- update customer order part_id 13 instead part_id 14 for customer_id = 16
UPDATE customer_orders 
SET 
    part_id = 13
WHERE
    customer_id = 16;

-- For CEO
-- Add 1000 to the salary for employees that their salary is last than 8000
UPDATE personal 
SET 
    salary = salary + 1000
WHERE
    salary < 8000;

-- Delete all employees that older than 65
DELETE FROM personal 
WHERE
    TIMESTAMPDIFF(YEAR,
    date_of_birth,
    CURDATE()) > 65;
    
-- For employees
-- Update wrong first name
UPDATE personal 
SET 
    first_name = 'Wilborn'
WHERE
    first_name = 'Wilburn';

-- Update address of employee that his address_id = 12
UPDATE personal,
    address 
SET 
    city = 'METZ',
    street_name = 'Vine Street',
    street_number = 1719
WHERE
    personal.address_id = 12
        AND personal.address_id = address.address_id;

-- Trigger before_part_sale_update will be activated while using this update and set amount to zero
UPDATE bike_parts 
SET 
    amount = - 1
WHERE
    part_id = 1;