CREATE SCHEMA bike_factory;

USE bike_factory;

-- Create personal table 
CREATE TABLE personal (
    personal_id INT,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    salary INT NOT NULL,
    department_id INT,
    personal_type VARCHAR(100),
    address_id INT,
    phone_number INT,
    email VARCHAR(100),
    date_of_birth DATE
);

-- Create Department table;
CREATE TABLE department (
    department_id INT,
    department_name VARCHAR(100)
);

-- Create Bike_parts table
CREATE TABLE bike_parts (
    part_id INT,
    part_name VARCHAR(100),
    company_name VARCHAR(100),
    part_type VARCHAR(100),
    amount INT NOT NULL,
    price INT
);

-- Create Supplier table
CREATE TABLE supplier (
    supplier_id INT,
    address_id INT,
    supplier_name VARCHAR(50),
    phone_number INT,
    email VARCHAR(100)
);

-- Create Customer table
CREATE TABLE customer (
    customer_id INT,
    address_id INT,
    customer_fname VARCHAR(50),
    customer_lname VARCHAR(50),
    customer_type VARCHAR(50),
    phone_number INT,
    email VARCHAR(100)
);

-- Create Address table
CREATE TABLE address (
    address_id INT,
    city VARCHAR(50),
    street_name VARCHAR(50),
    street_number INT
);

-- Create Supply_orders table
CREATE TABLE supply_orders (
    order_number INT,
    supplier_id INT,
    part_id INT,
    date_of_supply DATE
);

-- Create Costumer_orders table
CREATE TABLE customer_orders (
    order_number INT,
    customer_id INT,
    part_id INT,
    date_of_supply DATE
);
