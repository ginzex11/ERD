USE bike_factory;

DELIMITER $$
CREATE TRIGGER before_part_sale_update
BEFORE UPDATE
ON bike_parts FOR EACH ROW
BEGIN
	IF old.amount <= 0 THEN
		SET new.amount = 0;
    END IF;
END $$