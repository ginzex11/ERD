USE bike_factory;

-- For CEO
-- view for displaying all the customers who bought from the factory
CREATE VIEW customers_view AS
    (SELECT 
        customer_fname,
        customer_lname,
        part_name,
        company_name,
        part_type,
        date_of_supply
    FROM
        customer,
        customer_orders,
        bike_parts
    WHERE
        customer.customer_id = customer_orders.customer_id
            AND customer_orders.part_id = bike_parts.part_id);
    
SELECT 
    *
FROM
    customers_view;

-- view for displaying all the suppliers that the factory order from them
CREATE VIEW suppliers_view AS
    (SELECT 
        supplier_name,
        part_name,
        company_name,
        part_type,
        date_of_supply
    FROM
        supplier,
        supply_orders,
        bike_parts
    WHERE
        supplier.supplier_id = supply_orders.supplier_id
            AND supply_orders.part_id = bike_parts.part_id);
    
SELECT 
    *
FROM
    suppliers_view;
    
-- For CEO/budget department
-- view for displaying all the information about the bike parts
CREATE VIEW parts_information_view AS
    (SELECT 
        *
    FROM
        bike_parts);
        
SELECT 
    *
FROM
    parts_information_view;